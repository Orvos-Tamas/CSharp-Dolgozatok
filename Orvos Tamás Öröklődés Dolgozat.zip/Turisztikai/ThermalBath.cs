﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Turisztikai
{
    internal class ThermalBath : Beach
    {
        public ThermalBath(string country, string city, string name, int openingTime, int closingTime, bool enclosedSpace, int hourlyPrice, int ageLimit, bool massage) : base(country, city, name, openingTime, closingTime, enclosedSpace, hourlyPrice)
        {
            AgeLimit = ageLimit;
            Massage = massage;
            Slides = [];
        }

        public int AgeLimit { get; set; }
        public bool Massage { get; set; }
    }
}
