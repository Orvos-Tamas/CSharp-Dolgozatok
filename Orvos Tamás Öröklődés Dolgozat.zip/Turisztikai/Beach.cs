﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Turisztikai
{
    internal class Beach : Attraction
    {
        public Beach(string country, string city, string name, int openingTime, int closingTime, bool enclosedSpace, int hourlyPrice) : base(country, city, name, openingTime, closingTime)
        {
            EnclosedSpace = enclosedSpace;
            HourlyPrice = hourlyPrice;
            Slides = [];
        }

        public bool EnclosedSpace { get; set; }
        public List<string> Slides { get; set; }
        public int HourlyPrice { get; set; }

        public void AddSlides(string description)
        {
            Slides.Add(description);
        }

        public void AddSlides(List<string> descriptionList)
        {
            descriptionList.ForEach(description => Slides.Add(description));
        }
    }
}
