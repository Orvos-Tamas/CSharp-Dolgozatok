﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Turisztikai
{
    abstract class Attraction
    {
        protected Attraction(string country, string city, string name, int openingTime, int closingTime)
        {
            Country = country;
            City = city;
            Name = name;
            OpeningTime = openingTime;
            ClosingTime = closingTime;
        }

        protected Attraction(string country, string city, string name)
        {
            Country = country;
            City = city;
            Name = name;
            OpeningTime = 0;
            ClosingTime = 24;
        }

        public string Country { get; set; }
        public string City { get; set; }
        public string Name { get; set; }
        public int OpeningTime { get; set; }
        public int ClosingTime { get; set; }
    }
}
