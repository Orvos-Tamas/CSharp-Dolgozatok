﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Turisztikai
{
    internal class Museum : Attraction
    {
        public Museum(string country, string city, string name, int openingTime, int closingTime, string theme, bool canTravelForFree, int entryFee) : base(country, city, name, openingTime, closingTime)
        {
            Theme = theme;
            CanTravelForFree = canTravelForFree;
            EntryFee = entryFee;
        }

        public string Theme { get; set; }
        public bool CanTravelForFree { get; set; }
        public int EntryFee { get; set; }
        public double GroupDiscount(int numberOfPeople)
        {
            double price = numberOfPeople * EntryFee;

            if (numberOfPeople > 20)
                return price * 0.7;
            else if (numberOfPeople >= 10 && numberOfPeople <= 20)
                return price * 0.8;
            else
                return price;
        }
    }
}
