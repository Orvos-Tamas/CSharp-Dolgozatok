﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace Turisztikai
{
    internal class ReadData
    {
        List<Attraction> attractions;

        public ReadData(string fileName)
        {
            attractions = [];
            foreach (var item in File.ReadLines(fileName))
            {
                string[] parts = item.Split(';');
                string country = parts[1];
                string city = parts[2];
                string name = parts[3];
                int openingTime = Convert.ToInt32(parts[4]);
                int closingTime = Convert.ToInt32(parts[5]);
                switch (parts[0])
                {
                    case "museum":
                        string theme = parts[6];
                        bool canTravelForFree = parts[7] == "Yes" ? true : false;
                        int entryFee = Convert.ToInt32(parts[8]);
                        Museum newMuseum = new Museum(country, city, name, openingTime, closingTime, theme, canTravelForFree, entryFee);
                        attractions.Add(newMuseum);
                        break;
                    case "beach":
                        bool enclosedSpace = parts[6] == "Enclosed" ? true : false;
                        int hourlyPrice = Convert.ToInt32(parts[7]);
                        Beach newBeach = new Beach(country, city, name, openingTime, closingTime, enclosedSpace, hourlyPrice);
                        attractions.Add(newBeach);
                        break;
                    case "thermal bath":
                        enclosedSpace = parts[6] == "Enclosed" ? true : false;
                        hourlyPrice = Convert.ToInt32(parts[7]);
                        int ageLimit = Convert.ToInt32(parts[8]);
                        bool massage = parts[9] == "Yes" ? true : false;
                        ThermalBath newThermalBath = new ThermalBath(country, city, name, openingTime, closingTime, enclosedSpace, hourlyPrice, ageLimit, massage);
                        attractions.Add(newThermalBath);
                        break;
                }
            }
        }
    }
}
