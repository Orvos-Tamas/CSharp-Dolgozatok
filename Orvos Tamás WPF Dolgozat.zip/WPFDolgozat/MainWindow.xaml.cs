﻿using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPFDolgozat
{
    public partial class MainWindow : Window
    {
        List<WindPowerplant> data = new List<WindPowerplant>();
        public MainWindow()
        {
            InitializeComponent();
            ReadTxtFile();
            Display(data, dataListBox);
        }

        //Task 1
        void ReadTxtFile()
        {
            foreach (var file in File.ReadAllLines("szeleromu.txt", Encoding.UTF8))
            {
                string[] line = file.Split(";");
                string location = line[0];
                int units = int.Parse(line[1]);  
                int production = int.Parse(line[2]);
                int year = int.Parse(line[3]);
                WindPowerplant windPowerplant = new(location, units, production, year);
                data.Add(windPowerplant);
            }
        }

        void Display(List<WindPowerplant> input, ListBox output)
        {
            output.ItemsSource = input.Select(x => x.dataListBoxItem);
        }

        //Task 2
        private void productionDisplayButton_Click(object sender, RoutedEventArgs e)
        {
            var powerPlantsWithMaxProduction = data.Where(x => x.Production == data.Max(x => x.Production));
            string output = "";
            foreach (var item in powerPlantsWithMaxProduction)
            {
                output += $"{item.Location} - {item.Units} - {item.Production} - {item.Year}\n";
            }
            MessageBox.Show(output);
        }

        //Task 3
        private void averageProductionButton_Click(object sender, RoutedEventArgs e)
        {
            double average = Math.Round(data.Where(x => x.Year == 2010).Average(x => x.Production), 2);
            int numberOfUnits = data.Where(x => x.Year == 2010).Sum(x => x.Units);
            MessageBox.Show(Convert.ToString($"{average} W, {numberOfUnits}"));
        }

        //Task 4
        private void searchMaxProductionButton_Click(object sender, RoutedEventArgs e)
        {
            string searchInput = productionInputTextBox.Text.ToLower();
            try
            {
                List<WindPowerplant> matching = data.Where(x => x.Production == Convert.ToInt32(searchInput)).ToList();
                Display(matching, newListBox);
                searchResultAmount.Content = matching.Count();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Please input a number!");
            }      
        }

        //Task 6
        private void avgProductionByCategories_Click(object sender, RoutedEventArgs e)
        {
            double aaverage = data.Where(x => x.Production >= 1000).Average(x => x.Production);
            double baverage = data.Where(x => x.Production > 500 && x.Production < 1000).Average(x => x.Production);
            double caverage = data.Where(x => x.Production < 500).Average(x => x.Production);

            MessageBox.Show($"Average of category 'A': {aaverage:N2}\n " +
                            $"Average of category 'B': {baverage:N2}\n " +
                            $"Average of category 'C': {caverage:N2}");
        }

        //Task 7
        private void searchLocation_Click(object sender, RoutedEventArgs e)
        {
            string searchInput = locationInputTextBox.Text.ToLower();
            List<WindPowerplant> matching = data.Where(x => x.Location.ToLower().Contains(searchInput)).ToList();
            if (matching.Count == 0) MessageBox.Show("Could not find any results");

            Display(matching,newListBox);
        }
    }
}