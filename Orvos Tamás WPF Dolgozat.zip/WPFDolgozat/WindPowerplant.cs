﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Xaml.Schema;

namespace WPFDolgozat
{
    internal class WindPowerplant
    {
        public string Location { get; set; }
        public int Units { get; set; }
        public int Production { get; set; }
        public int Year { get; set; }

        public WindPowerplant(string location, int units, int production, int year) 
        { 
            Location = location;
            Units = units;
            Production = production;
            Year = year;
        }

        public override string ToString()
        {
            return $"{Location} - {Units} - {Production} - {Year}";
        }

        public ListBoxItem dataListBoxItem => new()
        {
            Content = ToString()
        };

        public char Categorize(WindPowerplant windPowerplant)
        {
            if (windPowerplant.Production >= 1000)
                return 'A';
            else if (windPowerplant.Production > 500)
                return 'B';
            else
                return 'C';
        }
    }
}
