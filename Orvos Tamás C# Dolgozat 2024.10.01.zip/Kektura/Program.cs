﻿namespace Kektura
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Tasks tasks = new("kektura.txt");
            tasks.Task3();
            tasks.Task4();
            tasks.Task5();
            tasks.Task6();
            tasks.Task7();
            tasks.Task8();
            tasks.Task9();
            tasks.Task10();
        }
    }
}
