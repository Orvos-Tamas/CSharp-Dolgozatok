﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kektura
{
    internal class Tasks
    {
        private List<Routes> routesList;

        public Tasks(string filePath)
        {
            routesList = new List<Routes>();
            foreach (var item in File.ReadAllLines(filePath).Skip(1))
            {
                var part = item.Split(';');
                string route = part[0];
                double distance = Convert.ToDouble(part[1].Replace(',', '.'));
                int height = Convert.ToInt32(part[2]);
                int completion = Convert.ToInt32(part[3]);
                Routes newRoute = new Routes(route, distance, height, completion);
                routesList.Add(newRoute);
            }
        }

        public void Task3()
        {
            Console.WriteLine($"Number of routes in the list: {routesList.Count}");
            var routesContainingPilis = routesList.Where(x => x.Route.ToLower().Contains("pilis")).ToList();
            double percentage = 100.0 * routesContainingPilis.Count /routesList.Count;
            Console.WriteLine($"{routesContainingPilis.Count} routes have Pilis in their name, this is {percentage:N2}% of all routes");
        }

        public void Task4()
        {
            var shortestRoute = routesList.OrderBy(x => x.Distance).First();
            Console.WriteLine($"The shortest route is {shortestRoute.Route}, it's length is {shortestRoute.Distance}km");
        }

        public void Task5()
        {
            Console.Write($"Enter the minimum height: ");
            int minimumHeight = Convert.ToInt32(Console.ReadLine());
            Console.Write($"Enter the maximum height: ");
            int maximumHeight = Convert.ToInt32(Console.ReadLine());

            int numberOfRoutesBetweenMinAndMaxHeight = routesList.Where(x => x.Height >= minimumHeight && x.Height <= maximumHeight).Count();
            Console.WriteLine($"{numberOfRoutesBetweenMinAndMaxHeight} routes are between the minimum and maximum height");
        }

        public void Task6()
        {
            double averageTime = routesList.Where(x => x.Distance > 8).Average(x => x.Completion);
            Console.WriteLine($"It takes an average of {averageTime:N2} minutes to finish routes longer than 8km");
        }

        public void Task7()
        {
            //In Routes.cs
        }

        public void Task8()
        {
            foreach (var item in routesList.GroupBy(x => x.Height))
            {
                Console.WriteLine($"There are {item.Count()} routes with the height of {item.Key}m");
            }
        }

        public void Task9()
        {
            StreamWriter writer = new StreamWriter("200felett.txt");
            var routesLongerThan200Minutes = routesList.Where(x => x.Completion >= 200);
            
            foreach (var route in routesLongerThan200Minutes)
            {
                writer.WriteLine($"{route.Route};{route.Distance};{route.Height};{route.Completion}");
            }

            writer.WriteLine($"There are {routesLongerThan200Minutes.Count()} routes longer than or exactly 200 minutes");
            writer.Close();
        }

        public void Task10()
        {
            var shortestRoute = routesList.OrderBy(x => x.Distance).First();
            var longestRoute = routesList.OrderByDescending(x => x.Distance).First();
            double differenceInLength = longestRoute.Distance - shortestRoute.Distance;
            double percentage = 100.0 * shortestRoute.Distance / longestRoute.Distance;

            Console.WriteLine($"The difference in length between the shortest and longest routes is {differenceInLength}km. The shortest route is {percentage:N2}% of the longest route");
        }
    }
}
