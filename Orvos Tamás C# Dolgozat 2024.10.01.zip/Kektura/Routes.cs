﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kektura
{
    internal class Routes
    {
        public Routes(string route, double distance, int height, int completion)
        {
            Route = route;
            Distance = distance;
            Height = height;
            Completion = completion;
        }

        public string Route {  get; set; }
        public double Distance { get; set; }
        public int Height { get; set; }
        public int Completion { get; set; }
        public string Difficulty
        {
            get
            {
                return Distance < 4.5 ? "könnyű" :
                       Distance >= 4.5 && Distance <= 8 ? "közepes" : "nehéz";
            }
        }
    }
}
