﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Sandworm
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        int[,] matrix;
        int size = 17;
        public MainWindow()
        {
            InitializeComponent();
            for (int i = 0; i < size; i++)
            {
                matrixGrid.RowDefinitions.Add(new());
                matrixGrid.ColumnDefinitions.Add(new());
            }
            GenerateMatrix();
            DisplayMatrix();
        }

        public void GenerateMatrix()
        {
            matrix = new int[size, size];
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    if (i == 0 || i == size - 1 || j == 0 || j == size - 1)
                        matrix[i, j] = 0;
                    else
                        matrix[i, j] = 1;
                }
            }
        }

        public void DisplayMatrix()
        {
            Color[] colors = { Colors.White, Colors.Red, Colors.Yellow, Colors.Green };
            matrixGrid.Children.Clear();
            for (int i = 0; i < size; i++) 
            {
                for (int j = 0; j < size; j++)
                { 
                    Button button = new();
                    int colorIndex = matrix[i, j];
                    button.Background = new SolidColorBrush(colors[colorIndex]);
                    button.HorizontalAlignment = HorizontalAlignment.Stretch;
                    button.VerticalAlignment = VerticalAlignment.Stretch;
                    Grid.SetRow(button, i);
                    Grid.SetColumn(button, j);
                    if (matrix[i, j] != 0)
                        button.Click += Protect;
                    matrixGrid.Children.Add(button);
                }
            }
            Statistics();
        }

        public void Protect(object sender, RoutedEventArgs e)
        {
            Button clicked = sender as Button;
            int row = Grid.GetRow(clicked);
            int column = Grid.GetColumn(clicked);
            matrix[row, column] = 3;
            if (matrix[row + 1, column] == 1) matrix[row + 1, column] = 2;
            if (matrix[row - 1, column] == 1) matrix[row - 1, column] = 2;
            if (matrix[row, column + 1] == 1) matrix[row, column + 1] = 2;
            if (matrix[row, column - 1] == 1) matrix[row, column - 1] = 2;
            DisplayMatrix();
        }

        public void Statistics()
        {
            int areas = 0;
            int partiallyProtected = 0;
            int fullyProtected = 0;

            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    if (matrix[i, j] != 0)
                    {
                        areas++;
                    }

                    if (matrix[i, j] == 2) partiallyProtected++;
                    else if (matrix[i, j] == 3) fullyProtected++;
                }
            }

            int anyProtection = partiallyProtected + fullyProtected;
            double percentage = 100.0 * anyProtection / areas;

            statisticsLabel.Content = $"Number of partially protected areas: {partiallyProtected}; Number of fully protected areas: {fullyProtected}; Percentage of areas protected: {percentage:N2}%";
        }
    }
}